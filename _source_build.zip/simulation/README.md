# ClaimPulse — Simulation & Demo

One application, two wings.

- **SIMULATION** is the argument: how the thing works, and whether the numbers
  survive contact with a hostile question.
- **DEMO** is that argument running, seen from each stakeholder's own screen.

They share one rail, one design system and one model instance, because crossing
from the case to the product should not feel like crossing between two products.

---

## Status — all eleven screens built

| Wing | Screen | What it carries |
|---|---|---|
| Simulation | Overview | The case in one screen: the problem in filed numbers, what changes, what it is worth, who books it |
| Simulation | Solution architecture | The pipeline drawn as a mechanism, Gate 00 in full, and a live claim you can run through it |
| Simulation | TAT and repurposing | Where the 9.8 days go, and what happens to the released capacity |
| Simulation | Token economics | The bounded token table, four delivery paths, breakeven, build vs buy |
| Simulation | Financial stress test | Twelve live levers over the R6 engine, with a measured tornado |
| Simulation | Assumptions and sources | The filterable register, the frequency reconciliation, the five open decisions |
| Demo | Command centre | 64 claims, filterable and sortable, with the lane mix against book design |
| Demo | Claim inspector | One claim in full — why first, then the evidence, then the money |
| Demo | Customer app | The eight-step claimant flow in a phone, with no gallery button anywhere |
| Demo | Garage and surveyor | The repair network console and the surveyor desk |
| Demo | Value to management | Three plans side by side, the stakeholder split, the downside, the gates |

Verified in both themes at 1600px and at 390px: no JavaScript errors, no horizontal
overflow, every screen populated.

---

## Run it

No build step, no package manager, no framework. Plain HTML, CSS and ES5-safe JS.

```
python3 -m http.server 8000     # then open http://localhost:8000
```

It also opens straight off the filesystem (`file://`) — every script is a plain
`<script>`, deliberately, so nothing depends on a module server or a CDN.
The only external request is the Google Fonts stylesheet; if it fails, the
fallback stack (`Segoe UI` / system sans) carries the whole design.

---

## Structure

```
index.html                  the shell: top bar, rail, main
assets/
  css/
    tokens.css              design system — proportion, colour, themes
    base.css                reset, typography, primitives
    layout.css              shell, rail, grids, breakpoints
    components.css          cards, tiles, levers, tables, charts, tooltip
  img/
    bajaj-finserv.svg       the lockup, rendered as a CSS mask so it takes
                            brand blue on light and reverses to white on dark
  js/
    core.js                 DOM helpers, Indian number formatting, theme, tooltip
    model.js                the R6 engine + 35 self-checks
    engine.js               Gate 00, five engines, Trust Score, lane routing
    claims.js               six story claims + a seeded queue of 58
    charts.js               the SVG chart kit
    ui.js                   shared view furniture (tiles, tables, callouts)
    diagrams.js             the pipeline drawing and the journey comparison
    app.js                  rail, router, rail collapse, theme wiring
    views/                  one file per screen, eleven of them
```

### The rail

The button in the top bar does two jobs. On a wide screen it collapses the rail to
icons (248px → 68px, remembered in `localStorage`); on a narrow one there is no room
for a collapsed rail either, so it opens and closes the drawer instead. Collapsed
rail links show their label as a chip on hover, so nothing becomes unfindable.

The theme control lives at the foot of the rail rather than in the top bar, which
leaves the top-right for the Bajaj Finserv lockup.

---

## The model

`model.js` is a faithful re-implementation of
`ClaimPulse_Investor_Dashboard_R6.xlsx` — Sheet 1 (inputs), Sheet 3 (Workings)
and Sheet 4 (Forecast). Every function carries the Excel ref it reproduces.

`CPModel.selfCheck()` asserts the engine against the workbook's own computed
values on **35 anchors** across all three plans. It runs on every page load and
prints to the console; the stress-test screen shows the result as a badge. If a
formula here ever drifts from the Excel, the badge goes red and says so.

**`INPUTS` is the only place a number is typed.** Everything else is derived.

### What changed in R6 — read before touching any benefit line

- **W-18 labour saving is zero and stays zero.** Headcount is not cut, so no
  labour cost leaves the P&L.
- **W-22a books released capacity as redeployed output**, at the B-29
  realisation rate. It sits *outside* both ratios.
- **W-23a is marketing investment — a cost, not a benefit.** It is the same
  rupees the Hunt & Farm plan proposes spending.

Anything quoting **₹43.31 Cr** is pre-R6 and is wrong. The R6 headline is
**₹30.95 Cr** net, **20.07 months** from kickoff, **₹51.06 Cr** three-year NPV.

---

## Design system

**Proportion.** Spacing runs on the Fibonacci sequence (2 3 5 8 13 21 34 55 89
144), which converges on the golden ratio and lands on whole pixels. Type runs on
a modular scale of 1.272 — the square root of phi — because a full phi step
between adjacent UI sizes is too violent to read. Layout splits that have a
dominant and a subordinate column use 1 : 1.618 directly (`.g-phi`). Body line
height is 1.618; headings 1.236.

**Colour.** One brand hue (Bajaj blue) carries structure and action. One warm
complement carries emphasis and gives the light theme its ground — the light
theme is a warm parchment, not white, so the blue reads as deliberate.

The categorical data palette is a **validated set**: it passes the lightness
band, chroma floor, adjacent-pair colourblind separation and the normal-vision
floor against both surfaces. Three light-mode slots sit under 3:1 contrast, so
every chart using them ships direct labels or a table view — the relief rule.
Status colours (lane green / amber / red) are **reserved** and never reused for a
data series, and never carry meaning by colour alone.

**Themes.** Light, dark, and system. Both are gradient grounds. Dark is selected
for the dark surface rather than being an inverted light theme.

---

## The demo engine

`engine.js` implements Gate 00, five engines, Trust Score fusion and lane routing.
Three rules are enforced by the code's structure rather than by comment:

1. **Gate 00 runs before any engine.** On a hard fail `process()` returns
   immediately — the downstream engines are `null`, the Trust Score is `null`, and
   the inspector shows them as NOT RUN. Showing a score there would mean computing
   it, which is exactly what the architecture avoids.
2. **The Trust Score is a weighted sum**, so the contribution column always adds to
   the headline figure. Weights: gate 30, doc 20, CV 15, fraud 25, policy 10.
3. **Nothing above ₹50,000 auto-settles**, however clean — the IRDAI corridor
   (A-11) caps the green lane by law, not by choice.

Routing floors are green 82, amber 55, ring 0.35. These are the demo's own
calibration of the lane shares, not a workbook input, and they are labelled as such
on screen.

`claims.js` holds six hand-built claims — one per routing behaviour — plus a seeded
generator for 58 more. The generator shapes the *evidence*, never the lane; every
claim is still routed by the engine on its own score. The mix that comes out is
67 / 22 / 11 against a book design of 65 / 25 / 10, and the command centre says so
rather than hiding the gap.

The seed is fixed, so the same queue appears every time. A demo that reshuffles
itself between rehearsal and the room is a demo that will surprise you in the room.

## Charts

Written, not imported — no CDN to fail in a competition room, every mark inherits
the theme tokens so light and dark are one implementation, and the geometry
follows the house spec: thin marks, 4px rounded data-ends anchored to the
baseline, 2px lines, ≥8px markers, a 2px surface gap between adjacent fills,
recessive grid, selective direct labels, hover tooltips throughout.

`waterfall` · `cashflow` · `hbar` · `stack` · `tornado` · `bullet` · `meter` · `contrib`

`hbar` takes `compact: true` for narrow columns and a `valueFmt` so counts and
rupees are not printed with two decimal places.

The stress test's tornado is **measured, not asserted**: each bar is the model
re-run with that one lever at its stated low and high, everything else held where
the user has it. The ranking is a result.

## The design system

The application is built from four primitives, not from cards.

**Panel** — the one surface. Glass over a lit ground: a gradient hairline at the
top edge, an inner highlight, a corner bloom and a shadow that falls the way light
falls. `data-dom` sets which domain it belongs to and paints all of that in that
domain's hue.

**Cell** — a metric inside a panel grid, divided by hairlines rather than by
another box. One panel, many cells. This is what stops a screen reading as a pile
of containers.

**Metric** — a label and a number, where the number is the loudest thing on the
panel and carries the domain gradient. The explanation arrives on hover, so twelve
metrics do not become twelve paragraphs.

**Dtable** — a real table with a sticky head, hairline rows, inline bars, hover
wash and clickable rows. Used wherever a table communicates better than cards,
which is more often than a dashboard usually admits.

### Six domains, six hues

Money is violet. Operations is cyan. The model is magenta. The customer is amber.
Risk is rose. People are emerald. These are *not* the chart-series colours — the
validated `d1..d8` set still owns every mark inside a chart. Domain hues carry
identity: the rule above a panel, the wash behind a cluster, the glow under a
headline number. A reader learns in ten seconds which colour means money.

### Motion means something

Three slow aurora blooms drift behind the whole application and a fine grain gives
the large surfaces tooth. Beyond that, nothing moves decoratively. A pulsing orb
means live. A sweeping bar means work in flight. A flashing number means it just
recomputed. A halo on a pipeline node means the claim is inside it right now.
Everything is suppressed under `prefers-reduced-motion`.

## The screens

**Overview** — five clusters in five colours: the book today, what the claim
becomes, where the book sits, what it is worth, who books it. The hero carries the
turnaround collapse as a tapered beam rather than two numbers side by side.

**Live book** — the book running at 600× to 30,000× real time, with the green-lane
share drawn converging on the 65% book design as claims arrive. That convergence is
the honest version of a lane-mix claim: a property of the claims, not a dashboard
setting.

**Live claim** — a processing theatre. Six stages across the top, each reporting
what it actually found; the nine-layer architecture lighting node by node as the
claim reaches it, with everything unreached dimmed; and one decision environment
with the engine results, the retrieved policy wording, the trust arithmetic and the
token cost as four tabs of a single component rather than six boxes.

**TAT and repurposing** — the capacity argument as a picture. A transformation
ribbon (current work → AI absorbs → capacity released → repurposed → output) over a
sankey showing which activities the platform absorbs and which work the team picks
up instead.

**Financial stress test** — a scenario engine. The twelve assumption levers live in
a drawer; the charts get the whole stage. A handle bottom-right says how many
assumptions are off default, and the header states which ones.

**Command centre** — stripped to what a manager acts on. The lane-distribution
chart is gone; an attention strip names the three queues they are accountable for
clearing, and the queue itself is searchable, filterable and sortable.

**Claim inspector** — opens on the actual book, all sixty-four claims, searchable
and filterable. Pick a row and the record opens: a one-sentence verdict and the
journey first, the trust arithmetic second, and the technical machinery in
collapsed sections that nobody has to read.

**Customer app** — clickable at every step, with a live checklist beside the
handset showing exactly what the system has understood and what it is still
capturing. During live capture the claimant sees the four frames filling in and
what each one taught the system.

**Garage and surveyor** — two operations consoles behind one switch, each a single
hierarchy: a headline, a network table you sort and select, and the selected row's
work list. No card grid.

**Value to management** — the executive dashboard, and where the command centre's
savings communication now lives. Six questions in the order a board asks them: what
changed, what we are saving, where capacity went, operational impact, financial
impact, future potential.


---

*Team Finsighters · NMIMS Mumbai · Bajaj Finserv ATOM Season 9 · PS_BFDL*
